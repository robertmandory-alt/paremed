// Emergency Personnel Performance Statistics Management System
// Main Application JavaScript

// Global State Management
const AppState = {
    currentUser: null,
    token: null,
    currentView: 'login',
    data: {
        users: [],
        personnel: [],
        shifts: [],
        performance: []
    }
};

// Persian Calendar Utilities
class PersianCalendar {
    constructor() {
        this.holidays = [
            // Common Iranian holidays (simplified)
            '1/1', '1/2', '1/3', '1/4', // Nowruz
            '3/14', '3/15', // Nature Day
            '11/22', // Revolution Day
            '12/29' // Islamic Republic Day
        ];
    }
    
    getCurrentPersianDate() {
        return new persianDate().format('YYYY/MM/DD');
    }
    
    getPersianYear() {
        return new persianDate().year();
    }
    
    getPersianMonth() {
        return new persianDate().month() + 1;
    }
    
    getDaysInMonth(year, month) {
        return new persianDate([year, month, 1]).daysInMonth();
    }
    
    isHoliday(month, day) {
        const dateStr = `${month}/${day}`;
        return this.holidays.includes(dateStr);
    }
    
    getMonthName(month) {
        const months = [
            'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
            'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
        ];
        return months[month - 1];
    }
    
    getDayName(dayOfWeek) {
        const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'];
        return days[dayOfWeek];
    }
}

// API Communication
class ApiClient {
    constructor() {
        this.baseURL = '';
    }
    
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };
        
        if (AppState.token) {
            config.headers['Authorization'] = `Bearer ${AppState.token}`;
        }
        
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'خطا در ارتباط با سرور');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    // Authentication
    async login(username, password) {
        return await this.request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    }
    
    // Users
    async getUsers() {
        return await this.request('/api/users');
    }
    
    async createUser(userData) {
        return await this.request('/api/users', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
    }
    
    // Personnel
    async getPersonnel() {
        return await this.request('/api/personnel');
    }
    
    async createPersonnel(personnelData) {
        return await this.request('/api/personnel', {
            method: 'POST',
            body: JSON.stringify(personnelData)
        });
    }
    
    // Shifts
    async getShifts() {
        return await this.request('/api/shifts');
    }
    
    async createShift(shiftData) {
        return await this.request('/api/shifts', {
            method: 'POST',
            body: JSON.stringify(shiftData)
        });
    }
    
    // Performance
    async getPerformance(year, month) {
        const params = new URLSearchParams();
        if (year) params.append('year', year);
        if (month) params.append('month', month);
        
        return await this.request(`/api/performance?${params}`);
    }
    
    async createPerformanceRecord(recordData) {
        return await this.request('/api/performance', {
            method: 'POST',
            body: JSON.stringify(recordData)
        });
    }
}

// UI Management
class UIManager {
    constructor() {
        this.calendar = new PersianCalendar();
        this.api = new ApiClient();
        this.currentModal = null;
    }
    
    showView(viewId) {
        // Hide all views
        document.querySelectorAll('#app > div').forEach(div => {
            div.classList.add('hidden');
        });
        
        // Show selected view
        const view = document.getElementById(viewId);
        if (view) {
            view.classList.remove('hidden');
        }
        
        AppState.currentView = viewId;
    }
    
    showLoading() {
        document.getElementById('loading').classList.remove('hidden');
    }
    
    hideLoading() {
        document.getElementById('loading').classList.add('hidden');
        document.getElementById('app').classList.remove('hidden');
    }
    
    showError(message, containerId = 'loginError') {
        const errorDiv = document.getElementById(containerId);
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.classList.remove('hidden');
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                errorDiv.classList.add('hidden');
            }, 5000);
        }
    }
    
    showSuccess(message) {
        // Create success notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 fade-in';
        notification.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-check-circle ml-2"></i>
                ${message}
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    createModal(title, content, actions = []) {
        // Remove existing modal
        if (this.currentModal) {
            this.currentModal.remove();
        }
        
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 z-50 flex items-center justify-center modal-backdrop fade-in';
        
        const actionsHTML = actions.map(action => 
            `<button class="px-4 py-2 rounded-lg ${action.class}" onclick="${action.onclick}">${action.text}</button>`
        ).join('');
        
        modal.innerHTML = `
            <div class="bg-white rounded-lg shadow-xl max-w-lg w-full mx-4 slide-up">
                <div class="flex justify-between items-center p-6 border-b">
                    <h3 class="text-lg font-medium">${title}</h3>
                    <button onclick="ui.closeModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="p-6">
                    ${content}
                </div>
                ${actions.length > 0 ? `
                <div class="flex justify-end space-x-2 space-x-reverse p-6 border-t bg-gray-50">
                    ${actionsHTML}
                </div>
                ` : ''}
            </div>
        `;
        
        document.body.appendChild(modal);
        this.currentModal = modal;
        
        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeModal();
            }
        });
    }
    
    closeModal() {
        if (this.currentModal) {
            this.currentModal.remove();
            this.currentModal = null;
        }
    }
}

// Authentication Manager
class AuthManager {
    constructor(ui, api) {
        this.ui = ui;
        this.api = api;
    }
    
    async login(username, password) {
        try {
            const response = await this.api.login(username, password);
            
            if (response.success) {
                AppState.currentUser = response.user;
                AppState.token = response.token;
                
                // Store in localStorage for persistence
                localStorage.setItem('emergency_user', JSON.stringify(response.user));
                localStorage.setItem('emergency_token', response.token);
                
                // Redirect based on role
                if (response.user.role === 'admin') {
                    this.ui.showView('adminDashboard');
                    document.getElementById('adminUserName').textContent = response.user.name;
                } else {
                    this.ui.showView('userDashboard');
                    // Load user dashboard
                    await userManager.loadUserDashboard();
                }
                
                return true;
            } else {
                this.ui.showError(response.message);
                return false;
            }
        } catch (error) {
            this.ui.showError('خطا در ورود به سیستم');
            return false;
        }
    }
    
    logout() {
        AppState.currentUser = null;
        AppState.token = null;
        
        // Clear localStorage
        localStorage.removeItem('emergency_user');
        localStorage.removeItem('emergency_token');
        
        // Redirect to login
        this.ui.showView('loginPage');
    }
    
    checkAuthStatus() {
        const user = localStorage.getItem('emergency_user');
        const token = localStorage.getItem('emergency_token');
        
        if (user && token) {
            AppState.currentUser = JSON.parse(user);
            AppState.token = token;
            
            if (AppState.currentUser.role === 'admin') {
                this.ui.showView('adminDashboard');
                document.getElementById('adminUserName').textContent = AppState.currentUser.name;
            } else {
                this.ui.showView('userDashboard');
                userManager.loadUserDashboard();
            }
        } else {
            this.ui.showView('loginPage');
        }
    }
}

// Admin Panel Manager
class AdminManager {
    constructor(ui, api) {
        this.ui = ui;
        this.api = api;
        this.currentSection = null;
    }
    
    async loadSection(sectionName) {
        const content = document.getElementById('adminContent');
        this.currentSection = sectionName;
        
        switch (sectionName) {
            case 'users':
                await this.loadUsersSection(content);
                break;
            case 'personnel':
                await this.loadPersonnelSection(content);
                break;
            case 'shifts':
                await this.loadShiftsSection(content);
                break;
            case 'performance':
                await this.loadPerformanceSection(content);
                break;
        }
        
        // Update active nav button
        document.querySelectorAll('.admin-nav-btn').forEach(btn => {
            btn.classList.remove('bg-gray-700');
            if (btn.dataset.section === sectionName) {
                btn.classList.add('bg-gray-700');
            }
        });
    }
    
    async loadUsersSection(content) {
        try {
            const response = await this.api.getUsers();
            const users = response.users || [];
            
            content.innerHTML = `
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-900">مدیریت کاربران</h2>
                    <button onclick="adminManager.showAddUserModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        <i class="fas fa-plus ml-2"></i>
                        افزودن کاربر
                    </button>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">نام</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">نام کاربری</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">نقش</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">وضعیت</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            ${users.map(user => `
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${user.name}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${user.username}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <span class="px-2 py-1 text-xs font-medium rounded-full ${user.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}">
                                            ${user.role === 'admin' ? 'مدیر' : 'کاربر عادی'}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <span class="px-2 py-1 text-xs font-medium rounded-full ${user.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                            ${user.is_active ? 'فعال' : 'غیرفعال'}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button onclick="adminManager.editUser(${user.id})" class="text-blue-600 hover:text-blue-900 ml-3">ویرایش</button>
                                        <button onclick="adminManager.deleteUser(${user.id})" class="text-red-600 hover:text-red-900">حذف</button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        } catch (error) {
            content.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
                    <p class="text-red-600">خطا در بارگذاری اطلاعات کاربران</p>
                </div>
            `;
        }
    }
    
    showAddUserModal() {
        const modalContent = `
            <form id="addUserForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">نام و نام خانوادگی</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">نام کاربری</label>
                    <input type="text" name="username" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">رمز عبور</label>
                    <input type="password" name="password" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">نقش</label>
                    <select name="role" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        <option value="user">کاربر عادی</option>
                        <option value="admin">مدیر</option>
                    </select>
                </div>
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="is_active" checked class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        <span class="mr-2 text-sm text-gray-700">فعال</span>
                    </label>
                </div>
            </form>
        `;
        
        this.ui.createModal('افزودن کاربر جدید', modalContent, [
            {
                text: 'لغو',
                class: 'bg-gray-300 text-gray-700 hover:bg-gray-400',
                onclick: 'ui.closeModal()'
            },
            {
                text: 'ذخیره',
                class: 'bg-blue-600 text-white hover:bg-blue-700',
                onclick: 'adminManager.saveUser()'
            }
        ]);
    }
    
    async saveUser() {
        const form = document.getElementById('addUserForm');
        const formData = new FormData(form);
        
        const userData = {
            name: formData.get('name'),
            username: formData.get('username'),
            password: formData.get('password'),
            role: formData.get('role'),
            is_active: formData.get('is_active') === 'on'
        };
        
        try {
            await this.api.createUser(userData);
            this.ui.closeModal();
            this.ui.showSuccess('کاربر با موفقیت اضافه شد');
            await this.loadSection('users');
        } catch (error) {
            this.ui.showError('خطا در ایجاد کاربر');
        }
    }
}

// User Panel Manager
class UserManager {
    constructor(ui, api) {
        this.ui = ui;
        this.api = api;
    }
    
    async loadUserDashboard() {
        const dashboard = document.getElementById('userDashboard');
        
        dashboard.innerHTML = `
            <div class="min-h-screen bg-gray-100">
                <!-- Top Navigation -->
                <nav class="bg-white shadow-lg border-b">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex justify-between h-16">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-user-tie text-2xl text-green-600"></i>
                                </div>
                                <div class="mr-4">
                                    <h1 class="text-xl font-bold text-gray-900">پنل کاربری - سرپرست پایگاه</h1>
                                </div>
                            </div>
                            
                            <div class="flex items-center space-x-4 space-x-reverse">
                                <span class="text-gray-700">خوش آمدید، <span id="userName">${AppState.currentUser.name}</span></span>
                                <button onclick="authManager.logout()" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors">
                                    <i class="fas fa-sign-out-alt ml-2"></i>
                                    خروج
                                </button>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- User Content -->
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold text-gray-900 mb-6">داشبورد کاربری</h2>
                        <p class="text-gray-600">محتوای پنل کاربری در حال توسعه است...</p>
                    </div>
                </div>
            </div>
        `;
    }
}

// Initialize Application
let ui, authManager, adminManager, userManager;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize managers
    ui = new UIManager();
    const api = new ApiClient();
    authManager = new AuthManager(ui, api);
    adminManager = new AdminManager(ui, api);
    userManager = new UserManager(ui, api);
    
    // Setup event listeners
    document.getElementById('loginForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        ui.showLoading();
        const success = await authManager.login(username, password);
        ui.hideLoading();
        
        if (!success) {
            document.getElementById('username').focus();
        }
    });
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', function() {
        authManager.logout();
    });
    
    // Admin navigation
    document.querySelectorAll('.admin-nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const section = this.dataset.section;
            adminManager.loadSection(section);
        });
    });
    
    // Check authentication status
    setTimeout(() => {
        ui.hideLoading();
        authManager.checkAuthStatus();
    }, 1000);
});

// Utility functions for modal actions
window.ui = ui;
window.adminManager = adminManager;
window.authManager = authManager;