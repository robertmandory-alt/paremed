-- Emergency Personnel Performance Statistics Management System
-- Supabase Database Schema
-- Execute these queries in your Supabase SQL Editor

-- Enable Row Level Security
-- ALTER database_name SET row_security = on;

-- 1. Users Table (System Users - Admin and Base Supervisors)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- In production, use proper hashing
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('admin', 'user')),
    is_active BOOLEAN DEFAULT true,
    
    -- Additional fields for base supervisors
    national_id VARCHAR(20),
    base_name VARCHAR(100),
    base_number VARCHAR(20),
    base_type VARCHAR(20) CHECK (base_type IN ('urban', 'road')), -- شهری، جاده‌ای
    digital_signature TEXT, -- Base64 encoded signature
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Personnel Table (Emergency Personnel Database)
CREATE TABLE IF NOT EXISTS personnel (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    national_id VARCHAR(20) UNIQUE NOT NULL,
    
    -- Employment status: رسمی (official) or طرحی (contractual)
    employment_status VARCHAR(20) DEFAULT 'official' CHECK (employment_status IN ('official', 'contractual')),
    
    -- Productivity status: بهره‌ور (productive) or غیر بهره‌ور (non-productive)
    productivity_status VARCHAR(20) DEFAULT 'productive' CHECK (productivity_status IN ('productive', 'non_productive')),
    
    -- Driver status: راننده (driver) or غیر راننده (non-driver)
    driver_status VARCHAR(20) DEFAULT 'non_driver' CHECK (driver_status IN ('driver', 'non_driver')),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Shifts Table (Work Shift Types)
CREATE TABLE IF NOT EXISTS shifts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL, -- e.g., "24 ساعته", "طولانی", "شبانه", "24 ساعته تعطیلی"
    equivalent_hours INTEGER NOT NULL, -- Numerical value for calculations
    shift_code VARCHAR(10) UNIQUE NOT NULL, -- e.g., "273"
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Bases Table (Emergency Bases)
CREATE TABLE IF NOT EXISTS bases (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    number VARCHAR(20) UNIQUE NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('urban', 'road')), -- شهری، جاده‌ای
    location VARCHAR(200),
    is_active BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Performance Records Table (Monthly Performance Data)
CREATE TABLE IF NOT EXISTS performance_records (
    id SERIAL PRIMARY KEY,
    
    -- Foreign Keys
    personnel_id INTEGER REFERENCES personnel(id) ON DELETE CASCADE,
    shift_id INTEGER REFERENCES shifts(id) ON DELETE SET NULL,
    base_id INTEGER REFERENCES bases(id) ON DELETE SET NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Who entered this record
    
    -- Date information (Persian/Shamsi calendar)
    year INTEGER NOT NULL, -- Persian year (e.g., 1403)
    month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12), -- Persian month (1-12)
    day INTEGER NOT NULL CHECK (day >= 1 AND day <= 31), -- Persian day (1-31)
    
    -- Performance data
    missions_count INTEGER DEFAULT 0, -- Number of missions
    meals_count INTEGER DEFAULT 0, -- Number of meals
    
    -- Additional metadata
    notes TEXT,
    is_holiday BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure no duplicate entries for same person on same date
    UNIQUE(personnel_id, year, month, day)
);

-- 6. Activity Logs Table (User Activity Monitoring)
CREATE TABLE IF NOT EXISTS activity_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL, -- e.g., 'login', 'create_record', 'update_personnel'
    entity_type VARCHAR(50), -- e.g., 'personnel', 'shift', 'performance'
    entity_id INTEGER,
    details JSONB, -- Additional details about the action
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_personnel_last_name ON personnel(last_name);
CREATE INDEX IF NOT EXISTS idx_personnel_national_id ON personnel(national_id);
CREATE INDEX IF NOT EXISTS idx_performance_date ON performance_records(year, month, day);
CREATE INDEX IF NOT EXISTS idx_performance_personnel ON performance_records(personnel_id);
CREATE INDEX IF NOT EXISTS idx_performance_user ON performance_records(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_date ON activity_logs(created_at);

-- Create Updated At Triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_personnel_updated_at BEFORE UPDATE ON personnel
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_shifts_updated_at BEFORE UPDATE ON shifts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bases_updated_at BEFORE UPDATE ON bases
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_performance_records_updated_at BEFORE UPDATE ON performance_records
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert Default Admin User
INSERT INTO users (name, username, password, role, is_active) 
VALUES ('مدیر سیستم', 'admin', 'admin1', 'admin', true)
ON CONFLICT (username) DO NOTHING;

-- Insert Sample Shift Types
INSERT INTO shifts (title, equivalent_hours, shift_code, description) VALUES
('24 ساعته', 24, '273', 'شیفت 24 ساعته معمولی'),
('طولانی', 12, '274', 'شیفت طولانی 12 ساعته'),
('شبانه', 8, '275', 'شیفت شبانه 8 ساعته'),
('24 ساعته تعطیلی', 24, '276', 'شیفت 24 ساعته در روزهای تعطیل'),
('روزانه', 8, '277', 'شیفت روزانه 8 ساعته')
ON CONFLICT (shift_code) DO NOTHING;

-- Insert Sample Bases
INSERT INTO bases (name, number, type, location) VALUES
('پایگاه اورژانس شهری 1', '101', 'urban', 'میدان آزادی'),
('پایگاه اورژانس شهری 2', '102', 'urban', 'میدان انقلاب'),
('پایگاه اورژانس جاده‌ای 1', '201', 'road', 'آزادراه تهران-کرج'),
('پایگاه اورژانس جاده‌ای 2', '202', 'road', 'جاده ساوه')
ON CONFLICT (number) DO NOTHING;

-- Insert Sample Personnel
INSERT INTO personnel (first_name, last_name, national_id, employment_status, productivity_status, driver_status) VALUES
('علی', 'احمدی', '1234567890', 'official', 'productive', 'driver'),
('حسن', 'محمدی', '1234567891', 'official', 'productive', 'non_driver'),
('فاطمه', 'حسینی', '1234567892', 'contractual', 'productive', 'driver'),
('مریم', 'کریمی', '1234567893', 'official', 'non_productive', 'non_driver'),
('رضا', 'نوری', '1234567894', 'contractual', 'productive', 'driver')
ON CONFLICT (national_id) DO NOTHING;

-- Row Level Security Policies (Optional - for production)
-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE bases ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE performance_records ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for different user roles
-- CREATE POLICY "Admins can access all users" ON users FOR ALL USING (auth.jwt() ->> 'role' = 'admin');
-- CREATE POLICY "Users can access their own data" ON users FOR SELECT USING (auth.uid()::text = id::text);

-- Views for Statistics and Reporting
CREATE OR REPLACE VIEW personnel_statistics AS
SELECT 
    p.id,
    p.first_name,
    p.last_name,
    p.national_id,
    p.employment_status,
    p.productivity_status,
    p.driver_status,
    COUNT(pr.id) as total_records,
    COALESCE(SUM(s.equivalent_hours), 0) as total_hours,
    COALESCE(SUM(pr.missions_count), 0) as total_missions,
    COALESCE(SUM(pr.meals_count), 0) as total_meals,
    COALESCE(SUM(CASE WHEN b.type = 'urban' THEN pr.missions_count ELSE 0 END), 0) as urban_missions,
    COALESCE(SUM(CASE WHEN b.type = 'road' THEN pr.missions_count ELSE 0 END), 0) as road_missions
FROM personnel p
LEFT JOIN performance_records pr ON p.id = pr.personnel_id
LEFT JOIN shifts s ON pr.shift_id = s.id
LEFT JOIN bases b ON pr.base_id = b.id
GROUP BY p.id, p.first_name, p.last_name, p.national_id, p.employment_status, p.productivity_status, p.driver_status;

-- Monthly Performance Summary View
CREATE OR REPLACE VIEW monthly_performance_summary AS
SELECT 
    pr.year,
    pr.month,
    COUNT(DISTINCT pr.personnel_id) as active_personnel,
    COUNT(pr.id) as total_shifts,
    SUM(s.equivalent_hours) as total_hours,
    SUM(pr.missions_count) as total_missions,
    SUM(pr.meals_count) as total_meals,
    SUM(CASE WHEN b.type = 'urban' THEN pr.missions_count ELSE 0 END) as urban_missions,
    SUM(CASE WHEN b.type = 'road' THEN pr.missions_count ELSE 0 END) as road_missions
FROM performance_records pr
LEFT JOIN shifts s ON pr.shift_id = s.id
LEFT JOIN bases b ON pr.base_id = b.id
GROUP BY pr.year, pr.month
ORDER BY pr.year DESC, pr.month DESC;

-- Grant necessary permissions (adjust as needed for your Supabase setup)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO anon, authenticated;