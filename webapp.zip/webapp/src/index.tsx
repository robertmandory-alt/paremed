import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { createClient } from '@supabase/supabase-js'

type Bindings = {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for all routes
app.use('/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization']
}))

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Initialize Supabase client
function getSupabaseClient(env: any) {
  return createClient(
    env.SUPABASE_URL || 'https://your-project.supabase.co',
    env.SUPABASE_ANON_KEY || 'your-anon-key'
  )
}

// API Routes for Authentication
app.post('/api/auth/login', async (c) => {
  try {
    const { username, password } = await c.req.json()
    
    // For demo purposes - in production you'd use Supabase Auth
    if (username === 'admin' && password === 'admin1') {
      return c.json({
        success: true,
        user: {
          id: 1,
          username: 'admin',
          role: 'admin',
          name: 'مدیر سیستم'
        },
        token: 'admin-token-123'
      })
    }
    
    // Check regular users in database here
    const supabase = getSupabaseClient(c.env)
    const { data: user } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .eq('password', password)
      .single()
    
    if (user && user.is_active) {
      return c.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          name: user.name
        },
        token: `user-token-${user.id}`
      })
    }
    
    return c.json({ success: false, message: 'نام کاربری یا رمز عبور اشتباه است' }, 401)
  } catch (error) {
    return c.json({ success: false, message: 'خطا در ورود به سیستم' }, 500)
  }
})

// API Routes for User Management
app.get('/api/users', async (c) => {
  const supabase = getSupabaseClient(c.env)
  const { data: users } = await supabase
    .from('users')
    .select('*')
    .order('created_at', { ascending: false })
  
  return c.json({ users })
})

app.post('/api/users', async (c) => {
  const userData = await c.req.json()
  const supabase = getSupabaseClient(c.env)
  
  const { data, error } = await supabase
    .from('users')
    .insert([userData])
    .select()
  
  if (error) {
    return c.json({ success: false, error: error.message }, 400)
  }
  
  return c.json({ success: true, user: data[0] })
})

// API Routes for Personnel Management
app.get('/api/personnel', async (c) => {
  const supabase = getSupabaseClient(c.env)
  const { data: personnel } = await supabase
    .from('personnel')
    .select('*')
    .order('last_name', { ascending: true })
  
  return c.json({ personnel })
})

app.post('/api/personnel', async (c) => {
  const personnelData = await c.req.json()
  const supabase = getSupabaseClient(c.env)
  
  const { data, error } = await supabase
    .from('personnel')
    .insert([personnelData])
    .select()
  
  if (error) {
    return c.json({ success: false, error: error.message }, 400)
  }
  
  return c.json({ success: true, personnel: data[0] })
})

// API Routes for Shift Management
app.get('/api/shifts', async (c) => {
  const supabase = getSupabaseClient(c.env)
  const { data: shifts } = await supabase
    .from('shifts')
    .select('*')
    .order('created_at', { ascending: false })
  
  return c.json({ shifts })
})

app.post('/api/shifts', async (c) => {
  const shiftData = await c.req.json()
  const supabase = getSupabaseClient(c.env)
  
  const { data, error } = await supabase
    .from('shifts')
    .insert([shiftData])
    .select()
  
  if (error) {
    return c.json({ success: false, error: error.message }, 400)
  }
  
  return c.json({ success: true, shift: data[0] })
})

// API Routes for Performance Management
app.get('/api/performance', async (c) => {
  const { year, month } = c.req.query()
  const supabase = getSupabaseClient(c.env)
  
  let query = supabase
    .from('performance_records')
    .select(`
      *,
      personnel (*),
      shifts (*)
    `)
  
  if (year && month) {
    query = query.eq('year', year).eq('month', month)
  }
  
  const { data: records } = await query.order('date', { ascending: true })
  
  return c.json({ records })
})

app.post('/api/performance', async (c) => {
  const performanceData = await c.req.json()
  const supabase = getSupabaseClient(c.env)
  
  const { data, error } = await supabase
    .from('performance_records')
    .insert([performanceData])
    .select()
  
  if (error) {
    return c.json({ success: false, error: error.message }, 400)
  }
  
  return c.json({ success: true, record: data[0] })
})

// Main application page
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>سیستم مدیریت آمار عملکرد پرسنل اورژانس</title>
        
        <!-- Fonts and Icons -->
        <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css" rel="stylesheet">
        
        <!-- Tailwind CSS with RTL Support -->
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
        tailwind.config = {
          theme: {
            extend: {
              fontFamily: {
                'vazir': ['Vazirmatn', 'sans-serif'],
              }
            }
          }
        }
        </script>
        
        <!-- Persian Calendar -->
        <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
        
        <!-- Chart.js for statistics -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        
        <!-- Excel Export -->
        <script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"></script>
        
        <!-- Custom Styles -->
        <link href="/static/style.css" rel="stylesheet">
        
        <style>
        body {
          font-family: 'Vazirmatn', sans-serif;
        }
        
        .rtl {
          direction: rtl;
          text-align: right;
        }
        
        .persian-calendar {
          direction: rtl;
        }
        
        .grid-cell {
          border: 1px solid #e5e7eb;
          padding: 8px;
          min-height: 60px;
          background: white;
        }
        
        .holiday-cell {
          background-color: #fee2e2 !important;
        }
        
        .shift-info {
          font-size: 0.75rem;
          line-height: 1.2;
        }
        
        .performance-grid {
          overflow-x: auto;
          max-height: 70vh;
        }
        
        .sticky-column {
          position: sticky;
          right: 0;
          background: white;
          z-index: 10;
          border-left: 2px solid #d1d5db;
        }
        
        .modal-backdrop {
          background-color: rgba(0, 0, 0, 0.5);
        }
        
        .fade-in {
          animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        .slide-up {
          animation: slideUp 0.3s ease-out;
        }
        
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        </style>
    </head>
    <body class="bg-gray-100 rtl font-vazir">
        <!-- Loading Screen -->
        <div id="loading" class="fixed inset-0 bg-white z-50 flex items-center justify-center">
            <div class="text-center">
                <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto"></div>
                <p class="mt-4 text-gray-600">در حال بارگذاری...</p>
            </div>
        </div>
        
        <!-- Main Application Container -->
        <div id="app" class="hidden min-h-screen">
            <!-- Login Page -->
            <div id="loginPage" class="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-700">
                <div class="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md slide-up">
                    <div class="text-center mb-8">
                        <div class="mx-auto h-20 w-20 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                            <i class="fas fa-user-shield text-3xl text-blue-600"></i>
                        </div>
                        <h1 class="text-2xl font-bold text-gray-900">ورود به سیستم</h1>
                        <p class="text-gray-600 mt-2">سیستم مدیریت آمار عملکرد پرسنل اورژانس</p>
                    </div>
                    
                    <form id="loginForm" class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">نام کاربری</label>
                            <input type="text" id="username" name="username" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">رمز عبور</label>
                            <input type="password" id="password" name="password" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        
                        <button type="submit" 
                            class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                            <i class="fas fa-sign-in-alt ml-2"></i>
                            ورود
                        </button>
                    </form>
                    
                    <div id="loginError" class="hidden mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-center"></div>
                </div>
            </div>
            
            <!-- Admin Dashboard -->
            <div id="adminDashboard" class="hidden">
                <!-- Top Navigation -->
                <nav class="bg-white shadow-lg border-b">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex justify-between h-16">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-chart-line text-2xl text-blue-600"></i>
                                </div>
                                <div class="mr-4">
                                    <h1 class="text-xl font-bold text-gray-900">پنل مدیریت سیستم</h1>
                                </div>
                            </div>
                            
                            <div class="flex items-center space-x-4 space-x-reverse">
                                <span class="text-gray-700">خوش آمدید، <span id="adminUserName">مدیر سیستم</span></span>
                                <button id="logoutBtn" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors">
                                    <i class="fas fa-sign-out-alt ml-2"></i>
                                    خروج
                                </button>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- Admin Sidebar and Content -->
                <div class="flex">
                    <!-- Sidebar -->
                    <div class="w-64 bg-gray-800 min-h-screen">
                        <div class="p-4">
                            <ul class="space-y-2">
                                <li>
                                    <button class="admin-nav-btn w-full text-right px-4 py-3 text-white hover:bg-gray-700 rounded-lg transition-colors" 
                                        data-section="users">
                                        <i class="fas fa-users ml-3"></i>
                                        مدیریت کاربران
                                    </button>
                                </li>
                                <li>
                                    <button class="admin-nav-btn w-full text-right px-4 py-3 text-white hover:bg-gray-700 rounded-lg transition-colors" 
                                        data-section="personnel">
                                        <i class="fas fa-id-card ml-3"></i>
                                        مدیریت پرسنل
                                    </button>
                                </li>
                                <li>
                                    <button class="admin-nav-btn w-full text-right px-4 py-3 text-white hover:bg-gray-700 rounded-lg transition-colors" 
                                        data-section="shifts">
                                        <i class="fas fa-clock ml-3"></i>
                                        مدیریت شیفت‌ها
                                    </button>
                                </li>
                                <li>
                                    <button class="admin-nav-btn w-full text-right px-4 py-3 text-white hover:bg-gray-700 rounded-lg transition-colors" 
                                        data-section="performance">
                                        <i class="fas fa-chart-bar ml-3"></i>
                                        مدیریت عملکرد
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <!-- Main Content Area -->
                    <div class="flex-1 p-6">
                        <div id="adminContent" class="bg-white rounded-lg shadow-lg p-6">
                            <div class="text-center">
                                <i class="fas fa-chart-line text-6xl text-gray-400 mb-4"></i>
                                <h2 class="text-2xl font-bold text-gray-700 mb-2">به پنل مدیریت خوش آمدید</h2>
                                <p class="text-gray-600">برای شروع، یکی از بخش‌های کناری را انتخاب کنید.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- User Dashboard -->
            <div id="userDashboard" class="hidden">
                <!-- User content will be loaded here -->
            </div>
        </div>
        
        <!-- JavaScript -->
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

export default app