# سیستم مدیریت آمار عملکرد پرسنل اورژانس

## نمای کلی پروژه
- **نام**: سیستم مدیریت آمار عملکرد پرسنل اورژانس (Emergency Personnel Performance Statistics Management System)
- **هدف**: ایجاد یک وب اپلیکیشن حرفه‌ای، مقیاس‌پذیر و هوشمند برای مدیریت متمرکز، ثبت و گزارش‌گیری آمار عملکرد ماهیانه پرسنل اورژانس
- **زبان سیستم**: فارسی (پشتیبانی کامل از RTL و تقویم شمسی)

## ویژگی‌های اصلی

### ✅ ویژگی‌های تکمیل شده
- **سیستم احراز هویت**: ورود با نام کاربری و رمز عبور (admin/admin1)
- **پنل مدیریت**: داشبورد مدیر با 4 ماژول اصلی
- **رابط کاربری فارسی**: پشتیبانی کامل از RTL و فونت Vazirmatn
- **ساختار پایگاه داده**: طراحی کامل جداول Supabase
- **API Routes**: endpoint های آماده برای تمامی عملیات CRUD

### 🔄 ویژگی‌های در دست توسعه
- **مدیریت کاربران**: افزودن، ویرایش، حذف کاربران
- **مدیریت پرسنل**: ثبت اطلاعات کامل پرسنل اورژانس
- **مدیریت شیفت‌ها**: تعریف انواع شیفت‌های کاری
- **گرید عملکرد**: نمایش و ویرایش عملکرد ماهیانه
- **گزارش‌گیری**: خروجی Excel، CSV، تصویر
- **پنل کاربری**: داشبورد سرپرستان پایگاه‌ها

## URLs فعلی
- **محلی (Development)**: http://localhost:3000
- **GitHub**: (در دست پیکربندی)
- **Production**: (آماده برای دپلوی به Cloudflare Pages)

## معماری داده‌ها

### مدل‌های داده اصلی
1. **کاربران (Users)**: مدیران و سرپرستان پایگاه‌ها
2. **پرسنل (Personnel)**: پرسنل اورژانس با اطلاعات کامل
3. **شیفت‌ها (Shifts)**: انواع شیفت‌های کاری قابل تعریف
4. **پایگاه‌ها (Bases)**: پایگاه‌های اورژانس (شهری/جاده‌ای)
5. **رکوردهای عملکرد (Performance Records)**: داده‌های ماهیانه
6. **لاگ فعالیت‌ها (Activity Logs)**: نظارت بر عملکرد کاربران

### سرویس‌های ذخیره‌سازی
- **پایگاه داده**: Supabase PostgreSQL با Real-time subscriptions
- **احراز هویت**: سیستم احراز هویت سفارشی با Supabase Auth
- **فایل‌ها**: Static files در Cloudflare Pages

### جریان داده‌ها
1. **ورود کاربر** → احراز هویت → تشخیص نقش (مدیر/کاربر)
2. **مدیر** → دسترسی به تمامی ماژول‌ها → مدیریت داده‌های پایه
3. **کاربر** → تکمیل پروفایل پایگاه → ثبت عملکرد ماهیانه
4. **Real-time Updates** → همگام‌سازی آنی در تمامی بخش‌ها

## راهنمای کاربری

### برای مدیران سیستم
1. **ورود**: با admin/admin1 وارد پنل مدیریت شوید
2. **مدیریت کاربران**: افزودن سرپرستان پایگاه‌ها
3. **مدیریت پرسنل**: ثبت اطلاعات پرسنل اورژانس
4. **تعریف شیفت‌ها**: ایجاد انواع شیفت‌های کاری
5. **نظارت بر عملکرد**: مشاهده و مدیریت عملکرد ماهیانه

### برای سرپرستان پایگاه‌ها
1. **ورود اولیه**: تکمیل پروفایل پایگاه (الزامی)
2. **انتخاب پرسنل**: اضافه کردن پرسنل از لیست تعریف شده
3. **ثبت عملکرد**: وارد کردن شیفت‌ها، ماموریت‌ها، وعده‌های غذایی
4. **ارسال نهایی**: تائید و ارسال اطلاعات ماهیانه

## وضعیت دپلوی
- **پلتفرم**: Cloudflare Pages
- **وضعیت**: ❌ در حال توسعه
- **تکنولوژی**: Hono + TypeScript + Supabase + TailwindCSS + Persian Calendar
- **آخرین بروزرسانی**: 2025-01-02

## Setup و نصب

### پیش‌نیازها
1. **حساب Supabase**: برای پایگاه داده و Real-time
2. **Cloudflare Account**: برای دپلوی نهایی
3. **Node.js**: برای development محلی

### مراحل راه‌اندازی

1. **Clone پروژه**:
```bash
git clone [repository-url]
cd webapp
```

2. **نصب Dependencies**:
```bash
npm install
```

3. **پیکربندی Supabase**:
   - ایجاد پروژه جدید در Supabase
   - اجرای `supabase-schema.sql` در SQL Editor
   - کپی کردن SUPABASE_URL و SUPABASE_ANON_KEY

4. **تنظیم Environment Variables**:
```bash
# فایل .dev.vars ایجاد کنید
echo "SUPABASE_URL=your-url" > .dev.vars
echo "SUPABASE_ANON_KEY=your-key" >> .dev.vars
```

5. **اجرای Development Server**:
```bash
npm run build
npm run dev:sandbox
```

### دپلوی Production
1. **تنظیم Secrets**:
```bash
wrangler secret put SUPABASE_URL --project-name emergency-stats
wrangler secret put SUPABASE_ANON_KEY --project-name emergency-stats
```

2. **دپلوی**:
```bash
npm run deploy:prod
```

## مشارکت در توسعه
- **Framework**: Hono (Cloudflare Workers)
- **Frontend**: Vanilla JavaScript + TailwindCSS
- **Database**: Supabase PostgreSQL
- **Calendar**: Persian/Shamsi Calendar Support
- **Export**: Client-side Excel/CSV generation
- **Real-time**: Supabase Real-time subscriptions

## لیسنس
MIT License - ایران Emergency Medical Services

---

**نکته مهم**: این سیستم برای استفاده در سازمان‌های اورژانس ایران طراحی شده و از استانداردهای محلی پیروی می‌کند.